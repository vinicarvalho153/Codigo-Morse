import java.util.Scanner;

class MorseTreeNode {
    char value;
    MorseTreeNode dot;
    MorseTreeNode dash;

    MorseTreeNode(char value) {
        this.value = value;
        this.dot = null;
        this.dash = null;
    }
}

class MorseTree {
    private MorseTreeNode root;

    public MorseTree() {
        root = new MorseTreeNode(' '); // Raiz vazia
        buildTree();
    }

    private void buildTree() {
        insert(".", 'E');
        insert("-", 'T');

        insert("..", 'I');
        insert(".-", 'A');
        insert("-.", 'N');
        insert("--", 'M');

        insert("...", 'S');
        insert("..-", 'U');
        insert(".-.", 'R');
        insert(".--", 'W');
        insert("-..", 'D');
        insert("-.-", 'K');
        insert("--.", 'G');
        insert("---", 'O');

        insert("....", 'H');
        insert("...-", 'V');
        insert("..-.", 'F');
        insert(".-..", 'L');
        insert(".--.", 'P');
        insert(".---", 'J');
        insert("-...", 'B');
        insert("-..-", 'X');
        insert("-.-.", 'C');
        insert("-.--", 'Y');
        insert("--..", 'Z');
        insert("--.-", 'Q');

        // Inserindo números
        insert("-----", '0');
        insert(".----", '1');
        insert("..---", '2');
        insert("...--", '3');
        insert("....-", '4');
        insert(".....", '5');
        insert("-....", '6');
        insert("--...", '7');
        insert("---..", '8');
        insert("----.", '9');
    }

    private void insert(char[] path, char value) {
        MorseTreeNode current = root;

        for (char step : path) {
            if (step == '.') {
                if (current.dot == null) {
                    current.dot = new MorseTreeNode(' ');
                }
                current = current.dot;
            } else if (step == '-') {
                if (current.dash == null) {
                    current.dash = new MorseTreeNode(' ');
                }
                current = current.dash;
            }
        }
        current.value = value;
    }

    public void insert(String path, char value) {
        insert(path.toCharArray(), value);
    }

    public char decode(String morseCode) {
        MorseTreeNode current = root;
        for (char symbol : morseCode.toCharArray()) {
            if (symbol == '.') {
                current = current.dot;
            } else if (symbol == '-') {
                current = current.dash;
            }
            if (current == null) {
                return ' '; // Código Morse inválido
            }
        }
        return current.value;
    }

    public String decodeMessage(String morseMessage) {
        String[] codes = morseMessage.split(" ");
        StringBuilder decodedMessage = new StringBuilder();
        for (String code : codes) {
            decodedMessage.append(decode(code));
        }
        return decodedMessage.toString();
    }

    public void printTree() {
        printTree(root, "");
    }

    private void printTree(MorseTreeNode node, String prefix) {
        if (node != null) {
            if (node.value != ' ') {
                System.out.println(prefix + ": " + node.value);
            }
            printTree(node.dot, prefix + ".");
            printTree(node.dash, prefix + "-");
        }
    }
}

public class CodigoMorse {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MorseTree morseTree = new MorseTree();

        System.out.println("Digite o código Morse (separado por espaços entre letras):");
        String morseInput = scanner.nextLine();
        String decodedMessage = morseTree.decodeMessage(morseInput);
        System.out.println("Mensagem decodificada: " + decodedMessage);

        System.out.println("\nÁrvore Morse:");
        morseTree.printTree();

        scanner.close();
    }
}
